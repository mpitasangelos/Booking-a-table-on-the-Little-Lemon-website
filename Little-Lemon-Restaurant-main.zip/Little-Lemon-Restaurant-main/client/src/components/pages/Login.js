import Login from '../sections/loginPages/Login';

export default function Order() {
    return (
        <>
            <Login />
        </>
    );
}